#ifndef _TC
#define _TC

#include "main.h"

void tc_task(void);
void RS1(void);
void RS2(void);
void RS3(void);
void RS4(void);
void RS5(void);
void int_status_check(void);

#endif
