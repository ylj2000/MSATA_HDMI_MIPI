#ifndef _PANEL
#define _PANEL

#include "main.h"

void Panel_Init(void);

#endif
